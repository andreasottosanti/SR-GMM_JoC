
#' Estimate the spatially regularized Gaussian mixture model (SR-GMM)
#' 
#' This function estimates the SR-GMM model via stochastic EM algorithm.
#'
#' @import Matrix
#' @import fields
#' @import NPVecchia
#'
#' @param datum an N x n matrix of numeric values, containing the values of N statistical units observed at n spatial locations.
#' @param locs an n x 2 matrix containing the coordinates of the n spatial locations.
#' @param K the number of clusters
#' @param nu (default 1) the hyperparameter of the Dirichlet distribution of the mixture weights. It must be a vector of length K. Alternatively, if of length 1, then the same hyperameter value will be assigned to every mixture component. 
#' @param penalization_theta the \eqn{L_2} regularization on the vector of cluster parameters. If = (default), no penalization is applied.
#' @param penalization_mu the \eqn{L_2} regularization on the mean cluster parameter. If 0 (default), no penalization is applied.
#' @param equal.prop (default FALSE) if TRUE, the mixture is forced to have clusters with equal proportions.
#' @param threshh (default 1e-4)  represents the minimum amount of variation that can be detected in the data. It is used to automatically determine the number of neighbors.
#' @param max_m (default 50) the maximum number of neighbors allowed.
#' @param maxit (default 100) the maximum number of iterations of the estimation algorithm.
#' @param init_mu (default NULL) a vector of length K. If passed, it is used as vector of cluster centroids to initiate the algorithm.
#' @param init_theta (default NULL) a vector of length 3, or a matrix of dimension K x 3. In case a vector is passed, then it is automatically transformed into a K x 3 matrix of equal rows. It is used as initialization of the cluster kernel parameters (in log scale).
#' @param clust_init (default NULL) a vector of length N. Every element must be an integer from 1 to K. If passed, the resulting partition of the data is used to initiate the estimation algorithm.
#' @param srgmm0 an object of class srgmm. If passed, it takes all the output elements of srgmm0 and use them to initiate the estimation.
#' @param optim.lim (c(-6, 4) default) the boundaries for the estimation of the cluster kernel parameters (in log scale).
#' @param iters.before.convergence (default 1) the number of consecutive iterations during which the increase in likelihood remains below \code{threshh}.
#' @param verbose (default TRUE) whether information of the estimation should be displayed or not.
#' @param seed (default NULL) if passed, it is used to set the seed of the simulation.
#'
#' @return an object of class \code{srgmm}, which is a list containing:
#' \itemize{
#'  \item \code{thetas}: a K x 3 matrix containing the estimates of the kernel parameters, for every cluster, in log scale;
#'  \item \code{mu}: a vector of length K giving the estimates of the cluster means;
#'  \item \code{Z}: a vector containing the final clustering labels;
#'  \item \code{omega}: a vector of length K containing the estimates of the mixture weights;
#'  \item \code{equal.prop}: a logical value indicating whether the mixture has been forced to have equal proportions;
#'  \item \code{data}: a list containing the data with columns reordered according to the MaxiMin criterion. The same ordering has been applied also to the matrix of coordinates. It contains also the ordering vector;
#'  \item \code{logL}: the log-likelihood values at each iteration (excluding the initialization point);
#'  \item \code{max.logL}: the maximum value of the log-likelihood function;
#'  \item \code{time}: the computational time, in seconds.
#' }
#' @export
#'
srgmm <- function (datum, locs, K = 2, 
                    conv_thres = 1e-4,
                    nu = 1, penalization_theta = 0, penalization_mu = 0, equal.prop = F, 
                   #corr_order = F, tapering_range = 0.4,
                    threshh = 0.001, max_m = 50,
                    #allocation_scheme = "parallel",  # it can be either 'parallel' or 'conditional'
                    #allocation_type = "class", # it can be 'class': classification EM, 'stoc': stochastic EM, 'caem': simulated annealing
                    maxit = 100,
                    init_mu = NULL, init_theta = NULL, clust_init = NULL, srgmm0 = NULL,
                    optim.lim = c(-6,4), 
                   #caem.param = c(1, .95), 
                    iters.before.convergence = 1, 
                    verbose = 100, seed = NULL)
{
  stochastic <- TRUE
  t0 <- Sys.time()
  set.seed(seed = seed)
  #if(!(allocation_scheme %in% c("parallel", "conditional"))) stop("Allocation scheme can be either 'parallel' or 'conditional'")
  #if(!(allocation_type %in% c("class", "stoc","caem"))) stop("Allocation type can be 'class', 'stoc' or 'caem'")
  N <- nrow(datum)
  n <- ncol(datum)
  if (nrow(locs) != n) {
    stop("The number of locations does not match the data!")
  }
  #if (corr_order) {
  #  ds <- rdist(locs)
  #  exp_const <- Exponential(ds, range = (tapering_range * max(ds)))
  #  cov_matrix <- cov(datum) * exp_const
  #  temp <- 1 - cov2cor(cov_matrix)
  #  orderd <- order_maximin_dist(temp)
  #  datum <- datum[, orderd]
  #  NNarray <- find_nn_dist(temp[orderd, orderd], max_m)
  #}
  #else {
    orderd <- orderMaxMinFaster(locs)
    datum <- datum[, orderd]
    temp <- rdist(locs[orderd, ])
    NNarray <- find_nn_dist(temp, max_m)
  #}
  if(length(nu) == 1 & K > 1) nu <- rep(nu, K)
  if(length(nu) > 1 & length(nu) != K) stop("The length of nu should be equal to 1 or the number of mixture components")

  # ---preparing the estimation
  if(!is.null(srgmm0)){
    if(class(srgmm0) != "srgmm") stop("The input is not an object of class srgmm")
    Z <- srgmm0$Z
    param <- srgmm0$thetas
    mu <- srgmm0$mu
    omega <- srgmm0$omega
  }
  if(!is.null(init_theta)){
    if (is.vector(init_theta)) param <- matrix(rep(init_theta, K), K, 3, byrow = T) else
      if(is.matrix(init_theta)){
        if(nrow(init_theta) == K) param <- init_theta else stop("input starting points are not coherent with K")
      }
  }
  if(is.null(init_theta) & is.null(srgmm0)) param <- matrix(runif(3*K, -1, 1), K, 3)
  if(!is.null(clust_init)) Z <- clust_init
  if(is.null(clust_init) & is.null(srgmm0)) Z <- sample(1:K, size = nrow(datum), replace = T)
  if(!is.null(init_mu)) mu <- init_mu
  if(is.null(init_mu) & is.null(srgmm0)) mu <- rnorm(K)
  if(!equal.prop){
    if(is.null(srgmm0)){
      omega <- as.vector(sapply(1:K, function(k) sum(Z == k)))/N
    }
  } else omega <- rep(1/K, K)
  
  
  verbose <- as.numeric(verbose)*100
  
  iter <- 1
  logL <- rep(-Inf, maxit)
  # computing the contribution to the posterior of each mixture component
  current_logL_components <- numeric(K)
  activeK <- which(sapply(1:K, function(l) sum(Z == l)) > 0)
  current_logL_components[activeK] <- sapply(activeK, function(k){
    logPosterior_k_cpp(datum = datum[Z == k,],
                       mu = mu[k],
                       thetas = param[k,],
                       omega = omega[k],
                       NNarray = NNarray,
                       threshh = threshh,
                       negativ = FALSE,
                       nu = nu[k],
                       penalization_theta = penalization_theta,
                       penalization_mu = penalization_mu)
  })
  if(length(activeK) < K){     # adding also the contribution of the priors related to the empty components (if present)
    current_logL_components[setdiff(1:K,activeK)] <-
      sapply(setdiff(1:K,activeK), function(k){
        logPrior_k_cpp(mu = mu[k],
                   thetas = param[k,],
                   omega = omega[k],
                   negativ = FALSE,
                   nu = nu[k],
                   penalization_theta = penalization_theta,
                   penalization_mu = penalization_mu)
      })
  }
  logL[iter] <- sum(current_logL_components)
  Z.store <- matrix(0, N, maxit)
  Z.store[,1] <- Z
  #responsabilities <- matrix(0, N, K)

# starting the cycle  -----------------------------------------------------
  while(T){
    iter <- iter + 1
    if(verbose) cat(paste("Iteration: ",iter,"\n"))

    logL[iter] <- logL[iter - 1]


# clustering --------------------------------------------------------------
    if(K > 1){   # potentially, the model can be run also with K = 1, which is the standard Katzfuss with non-zero mean and regularized thetas
      #if(allocation_scheme == "parallel"){
        #stop("Hey amigo, stop right there - this Algorithm was derived by AS and of course...it does not work")
        #log_responsabilities <- matrix(0, N, K)
        #for(k in 1:K){
        #  #uhat_k <- get_map(thetas = param[k,], datum = datum[Z == k,], NNarray = NNarray, threshh = threshh)
        #  posts_k <- get_posts_c(datum = datum[Z == k,], priors = thetas_to_priors_c(thetas = param[k,], n = ncol(datum), thresh = threshh), NNarray = NNarray)
        #  uhat_k <- samp_posts_fixed(posts = posts_k, NNarray = NNarray, bayesian = T, uhat = T)
        #  log_responsabilities[,k] <- log(omega[k]) + sequence_of_gaussians(datum = datum, mu = mu[k], U_tilde = uhat_k, NNarray = NNarray)
        #}
        #if(allocation_type == "class"){
        #  Z <- apply(log_responsabilities, 1, which.max)}
        #else if(allocation_type == "stoc"){
        #  responsabilities <- exp(log_responsabilities - matrix(as.vector(apply(log_responsabilities, 1, max)), N, K))
        #  responsabilities <- responsabilities / matrix(rowSums(responsabilities), N, K)
        #  Z <- apply(responsabilities, 1, function(p) sample(x = 1:K, size = 1, replace = F, prob = p))
        #}
        #else if(allocation_type == "caem") stop("Method currently not supported")
        #else stop("Allocation type can be 'class', 'stoc' or 'caem'")
      #}
      #if(allocation_scheme == "conditional"){
      Z <- gene_allocator_cpp(datum = datum,
                              old_contrib_lp = current_logL_components,
                              old_alloc_cpp = Z-1,
                              K = K, mu = mu, thetas_transp = t(param),
                              omega = omega, NNarray = NNarray, 
                              nu = nu, threshh = threshh,
                              penalization_theta = penalization_theta,
                              penalization_mu = penalization_mu,
                              stochastic = stochastic,verbose = verbose) + 1
      Z.store[,iter] <- Z
      } else {
      Z.store[, iter] <- Z <- rep(1, nrow(datum))
        }  # in case K = 1 and no clustering is needed

    
    N_k <- as.vector(sapply(1:K, function(k) sum(Z == k)))
    activeK <- which(sapply(1:K, function(k) sum(Z == k)) > 0)
    if(verbose>0) cat(paste("\n Clustering configuration: ",N_k,"\n"))

# estimation of the model parameters --------------------------------------

    # ---estimate the mixture weights
    if(!equal.prop) omega <- (N_k + nu - 1)/(N + sum(nu) - K)  # posterior mode of the dirichlet
    # ---estimate mus and thetas
    for(k in activeK){
      if(verbose>0) cat(paste("estimating mu",k,"\n"))
        mu[k] <- tryCatch({
          optim(par = mu[k], 
                logPosterior_k_MU_cpp, 
                omega = omega[k],
                thetas = param[k,], 
                datum = datum[Z == k,],
                NNarray = NNarray, 
                penalization_theta = penalization_theta,
                penalization_mu = penalization_mu, 
                nu = nu[k],
                negativ = TRUE,
                method="L-BFGS-B",
                lower = min(datum[Z == k,]), 
                upper = max(datum[Z == k,]), 
                control = list(maxit = 100))$par
        }, error = function(cond) {cat("ERRORE MU"); return(jitter(mu[k], amount = 0.01))})
        if(verbose>0) cat(paste("mu = ",mu[k],"\n"))

      # ---estimation of the theta_k vector
        if(verbose>0)  cat(paste("estimating theta",k,"\n"))
      param[k,] <- tryCatch({
        optim(param[k,], 
              logPosterior_k_THETA_cpp, 
              omega = omega[k],
              #thetas = param[k,],
              negativ = TRUE,
              mu = mu[k], datum = datum[Z == k,],
              NNarray = NNarray,                 
              penalization_theta = penalization_theta,
              penalization_mu = penalization_mu, 
              nu = nu[k],
              method="L-BFGS-B",
              lower = optim.lim[1], upper = optim.lim[2])$par
      }, error = function(cond) {cat("ERRORE THETA"); return(jitter(param[k,], amount = 0.01))})
      if(verbose>0) cat(param[k,],"\n")
    }
    if(length(activeK) < K){  # if there are some empty clusters, update the associated model parameters
      mu[setdiff(1:K, activeK)] <- 0
      param[setdiff(1:K, activeK),] <- 0
    }


# recompute the log-posterior ---------------------------------------------
    activeK <- which(sapply(1:K, function(l) sum(Z == l)) > 0)
    current_logL_components[activeK] <- sapply(activeK, function(k){
      logPosterior_k_cpp(datum = datum[Z == k,],
                     mu = mu[k],
                     thetas = param[k,],
                     omega = omega[k],
                     NNarray = NNarray,
                     threshh = threshh,
                     negativ = F,
                     nu = nu[k],
                     penalization_theta = penalization_theta,
                     penalization_mu = penalization_mu)
    })
    if(length(activeK) < K){     
      # adding also the contribution of the priors related to the empty components (if present)
      current_logL_components[setdiff(1:K,activeK)] <-
        sapply(setdiff(1:K,activeK), function(k){
          logPrior_k_cpp(mu = mu[k],
                     thetas = param[k,],
                     omega = omega[k],
                     negativ = F,
                     nu = nu[k],
                     penalization_theta = penalization_theta,
                     penalization_mu = penalization_mu)
        })
    }
    logL[iter] <- sum(current_logL_components)

    if(which.max(logL) == iter){
      cat("storing new results\n")
      best.results <- list(mu = mu, omega = omega, param = param, Z = Z)   # this is mostly useful with the stochastic version
    }
    if(verbose>0) cat("\n-------------------\n")
    # old version by fra
    # if(iter > 2){
    #   print(paste("Relative change:",abs(logL[iter] - logL[iter-1])/abs(logL[iter-1])))
    #   print(paste("Absolute change:",logL[iter]-logL[iter-1]))
    #   if( abs(logL[iter] - logL[iter-1])#/abs(logL[iter-1]) 
    #       <= conv_thres & 
    #       (logL[iter]-logL[iter-1]) >= 0){
    #     if(iter >= iters.before.convergence){
    #       if(verbose){
    #         cat("Converged\n")}
    #       logL <- logL[2:iter]
    #       break
    #     }
    #   }
    # }

    if(iter > 2){
      if(verbose>0) print(paste("Relative change:",abs(logL[iter] - logL[iter-1])/abs(logL[iter-1])))
      if(verbose>0) print(paste("Absolute change:",logL[iter]-logL[iter-1]))
      if((logL[iter]-logL[iter-1]) <= conv_thres & 
         (logL[iter]-logL[iter-1]) >= 0){
        if(iter >= iters.before.convergence){
          if(verbose){
            cat("|\n")
            cat("Converged\n")}
          logL <- logL[2:iter]
          break
        }
      }
    }
    if(verbose>0) cat("\n-------------------\n")
    
    if(iter == maxit){
      print("Maximum iterations reached")
      break
    }
  } # end loop
  t1 <- Sys.time()
  
  results <- list(thetas = best.results$param,
                  mu = best.results$mu,
                  Z = best.results$Z,
                  omega = best.results$omega,
                  equal.prop = equal.prop,
                  #responsabilities = responsabilities,
                  data = list(datum.ord = datum,
                              locs.ord = locs[orderd,],
                              order = orderd,
                              NNarray = NNarray,
                              threshh = threshh),
                  logL = logL,
                  max.logL = max(logL),
                  time = difftime(t1, t0, units=("secs"))[[1]])
  class(results) <- "srgmm"
  return(results)
}
