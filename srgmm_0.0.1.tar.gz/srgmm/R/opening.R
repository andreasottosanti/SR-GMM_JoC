.onAttach <- function(libname, pkgname) {
  packageStartupMessage("
  ____  ____            ____ __  __ __  __ 
 / ___||  _ \\          / ___|  \\/  |  \\/  |
 \\___ \\| |_) |  ____  | |  _| |\\/| | |\\/| |
  ___) |  _ <  |____| | |_| | |  | | |  | |
 |____/|_| \\_\\         \\____|_|  |_|_|  |_|
                        
Estimating spatially regularized Gaussian mixture models
                        ")
}