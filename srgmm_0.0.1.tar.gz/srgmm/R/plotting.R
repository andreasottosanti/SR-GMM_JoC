#' Plot SR-GMM objects
#' 
#' A representation of the data and of the results using \code{ggplot2} graphs.
#'
#' @import ggplot2
#' @param x an object of class \code{srgmm}
#' @param id (default NULL) it must be a string equals to a row.name of the matrix \code{x$data$datum.ord}. If passed, the corresponding observation is displayed.
#' @param k (default NULL) if passed and \code{assay != "rho_statistic"}, then the average values in the k-th cluster are displayed using the \code{assay} selected.
#' Otherwise, the k-th row of \code{rho_statistic} is displayed.
#' @param assay (default datum.ord) it specifies which data should be used for the plot.
#'
#' @return a \code{ggplot} object.
#' @export
#' 
#' @examples 
#' \dontrun{
#' # plot the first observation in the assay 'datum.ord',
#' plot(x, id = row.names(r$data$datum.ord)[1])
#' 
#' # plot the empirical mean of the observations cluster 1 using the assay 'datum.ord',
#' plot(x, k = 1)
#' 
#' # to display the rho statistic computed using the data in the first cluster,
#' plot(x, k = 1, assay = "rho_statistic")
#' }
#'
plot.srgmm <- function(x, id = NULL,  k = NULL, assay = "datum.ord"){
  if(class(x) != "srgmm") stop("x is not an object of class 'srgmm'")
  if(is.null(id) & is.null(k) | !is.null(id) & !is.null(k)) stop("select one type of plot")
  coord <- x$data$locs.ord
  if(!is.null(k)){
    if(assay != "rho_statistic"){
      if(k != 0)
        g <- ggplot(mapping = aes(x = coord[,1], y = coord[,2], col = colMeans(x$data[[assay]][x$Z == k,])))+
          geom_point()+theme_bw()+labs(x = "", y = "", col = paste("cluster",k))
   #   if(k == 0){
  #      val <- c()
  #      for(j in 1:max(x$Z)){
  #        val <- rbind(val, cbind(coord, colMeans(x$data$datum.ord[x$Z == j,]), rep(j, nrow(coord))))
  #      }
  #      val <- data.frame(val)
  #      names(val) <- c("x", "y", "val","cluster")
  #      g <- ggplot(val, mapping = aes(x, y, col = val))+
  #        geom_point()+theme_bw()+labs(x = "", y = "")+facet_wrap(~cluster)
  #    }
    } else {
      if(k != 0)
        g <- ggplot(mapping = aes(x = coord[,1], y = coord[,2], col = (x$data[[assay]][k,])))+
          geom_point()+theme_bw()+labs(x = "", y = "", col = paste("cluster",k))
    }
  }
  if(!is.null(id)){
    if(id %in% row.names(x$data[[assay]])){
      g <- ggplot(mapping = aes(x = coord[,1], y = coord[,2], col = x$data[[assay]][row.names(x$data[[assay]]) == id,]))+
        geom_point()+theme_bw()+labs(x = "", y = "", col = id)} else
          stop("The ID required does not match any element of row.names(x$data[[assay]])")
  }
  g
}
