
get_posts_fixed <- function (datum, priors, NNarray)
{
  if (length(priors) != 3) {
    stop("Priors should be a list of length 3!")
  }
  b <- priors[[2]]
  g <- priors[[3]]
  n <- ncol(datum)
  N <- nrow(datum)
  m <- min(ncol(g), ncol(NNarray))
  if (!(is.matrix(datum) && is.matrix(NNarray))) {
    stop("The data and NNarray must both be matrices")
  }
  if (ncol(datum) != nrow(NNarray)) {
    stop(paste("The number of locations (", ncol(datum),
               ") must equal the number of \n               rows of the neighbor matrix but given (",
               nrow(NNarray), ")", sep = ""))
  }
  if (ncol(NNarray) < 2) {
    stop("At least 2 neighbors are required (2 or more columns in NNarray)")
  }
  if (!is.integer(NNarray)) {
    warning("NNarray should consist of only integers (and/or NAs)!")
  }
  if (length(priors[[1]]) != n || length(b) != n || nrow(g) !=
      n || ncol(g) < 2) {
    stop("Please use priors created by thetas_to_priors for convenience. \n          The current priors are of the wrong size.")
  }
  a_post <- rep(0, n)
  b_post <- rep(0, n)
  muhat_post <- matrix(NA, nrow = n, ncol = m)
  G_post <- array(NA, dim = c(m, m, n))
  a_post <- priors[[1]] + N/2
  b_post[1] <- b[1] + t(datum[, 1] %*% datum[, 1])/2
  for (i in 2:n) {
    gind <- na.omit(NNarray[i, 1:m])
    nn <- length(gind)
    xi <- -datum[, gind]
    yi <- datum[, i]
    Ginv <- t(xi) %*% xi + diag(g[i, 1:nn]^(-1), nrow = nn)
    Ginv_chol <- chol(Ginv)
    muhat <- tryCatch({
      solve(Ginv_chol, solve(t(Ginv_chol), crossprod(xi,
                                                     yi)))
    }, error = function(e) {
      ginv(Ginv) %*% crossprod(xi, yi)
    })
    muhat_post[i, 1:nn] <- muhat
    G_post[1:nn, 1:nn, i] <- Ginv   # changed Ginv_chol with Ginv
    muhat_post[i, 1:nn] <- muhat
    b_post[i] <- b[i] + (t(yi) %*% yi - t(muhat) %*% Ginv %*%
                           muhat)/2
  }
  return(list(a_post, b_post, muhat_post, G_post))
}


samp_posts_fixed <- function (posts, NNarray, bayesian = TRUE, uhat = TRUE)
{
  n <- nrow(NNarray)
  m <- ncol(posts[[3]])
  if (ncol(NNarray) < m) {
    stop("The posteriors have more neighbors than the neighbor matrix accounts for!")
  }
  if (!is.integer(NNarray)) {
    warning("NNarray should consist of only integers (and/or NAs)!")
  }
  if (length(posts) != 4) {
    stop("There should be 4 elements in the list of posteriors! For simplicity,\n         it is recommended to use get_posts to generate these posteriors.")
  }
  if (length(posts[[1]]) != n || length(posts[[2]]) != n ||
      !all(dim(posts[[3]]) == c(n, m)) || !all(dim(posts[[4]]) ==
                                               c(m, m, n))) {
    stop("Please use get_posts to generate the posteriors. Some of \n          the current posteriors have incorrect dimensions.")
  }
  if (bayesian) {
    if (uhat) {
      n2 <- nrow(NNarray)
      d <- 1/sqrt(rinvgamma(1, posts[[1]][1], posts[[2]][1]))
      uhat <- sparseMatrix(i = 1, j = 1, x = d, dims = c(n2,
                                                         n2), triangular = TRUE)
      for (i in 2:n2) {
        gind <- na.omit(NNarray[i, 1:m]) # fixed
        nn <- length(gind)
        d <- rinvgamma(1, posts[[1]][i], posts[[2]][i])
        uhat[i, i] <- 1/sqrt(d)
        uhat[gind, i] <- uhat[i, i] * mvrnorm(1, posts[[3]][i,
                                                            1:nn], d * tcrossprod(ginv(posts[[4]][1:nn,
                                                                                                  1:nn, i])))
      }
      return(uhat)
    }
    else {
      n2 <- nrow(NNarray)
      sample1 <- rep(0, n)
      d <- rinvgamma(1, posts[[1]][1], posts[[2]][1])
      sample1[1] <- rnorm(1, 0, sqrt(d))
      for (i in 2:n2) {
        gind <- na.omit(NNarray[i, 1:m])   # fixed
        nn <- length(gind)
        d <- rinvgamma(1, posts[[1]][i], posts[[2]][i])
        uhat <- mvrnorm(1, posts[[3]][i, 1:nn], d *
                          tcrossprod(ginv(posts[[4]][1:nn, 1:nn, i])))
        sample1[i] <- rnorm(1, sum(uhat * (-sample1[gind])),
                            sqrt(d))
      }
      return(sample1)
    }
  }
  else {
    d <- (1/sqrt(posts[[2]][1])) * exp(lgamma((2 * posts[[1]][1] +
                                                 1)/2) - lgamma(posts[[1]][1]))
    uhat <- sparseMatrix(i = 1, j = 1, x = d, dims = c(n,
                                                       n), triangular = TRUE)
    for (i in 2:n) {
      gind <- na.omit(NNarray[i, 1:m])
      nn <- length(gind)
      uhat[i, i] <- (1/sqrt(posts[[2]][i])) * exp(lgamma((2 *
                                                            posts[[1]][i] + 1)/2) - lgamma(posts[[1]][i]))
      uhat[gind, i] <- posts[[3]][i, 1:nn] * uhat[i, i]
    }
    return(uhat)
  }
}
