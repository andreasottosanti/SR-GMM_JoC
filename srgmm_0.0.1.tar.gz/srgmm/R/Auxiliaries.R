

cor_row_from_precision <- function(Q, i) {
  n <- nrow(Q)
  Q <- as(Q, "symmetricMatrix")  # ensure symmetric (important for solver)
  
  # Solve Q x = e_i (i-th unit vector)
  ei <- rep(0, n); ei[i] <- 1
  xi <- solve(Q, ei)  # xi is the i-th column of Sigma
  
  sigma_ii <- xi[i]
  
  # Now we need diagonal elements of Sigma: Sigma[j,j] for j = 1...n
  # Diagonals of Sigma are the diagonal entries of inv(Q), but we don't want full inverse!
  # So we compute each Sigma[j,j] = solve(Q, e_j)[j], efficiently.
  
  # Create identity matrix as sparse
  diag_sigma <- numeric(n)
  for (j in 1:n) {
    ej <- numeric(n)
    ej[j] <- 1
    xj <- solve(Q, ej)
    diag_sigma[j] <- xj[j]
  }
  
  # Now compute correlation: rho_ij = xi[j] / sqrt(sigma_ii * sigma_jj)
  rho_i <- xi / sqrt(sigma_ii * diag_sigma)
  
  return(rho_i)
}





#' Compute the spatial connectivity based on the estimated covariances
#' 
#' Thus function computes \eqn{\rho^{(k)}_i}, the spatial connectivity of every spot i based on the estimated covariance of the k-th cluster.
#'
#' @param x an object of class \code{srgmm}.
#' @param k a vector indicating for which clusters the rho statistic should be computed.
#' @param compute_covariance (default TRUE) if TRUE, it computes the covariance matrix, otherwise it derives the \eqn{\rho^{(k)}_i} using directly the precision matrix.
#'
#' @returns An object of class \code{srgmm}, identical to \code{x} except that the \code{$data} element now also includes a matrix named \code{rho_statistic}, of dimension \code{K × n}, containing the estimated statistics.
#' Rows corresponding to clusters for which the statistic has not been computed are filled with zeros.
#' Note that applying this function to the same object multiple times does not reinitialize \code{x$data$rho_statistic}, allowing the rho statistic to be computed for different clusters at separate times.
#' @export
#' @examples
#' \dontrun{
#' # compute rho for clusters 1:3 using the covariance matrices
#' rho_k(x = x, k = 1:3, compute_covariance = TRUE)
#' }
#' 
#'
rho_k <- function(x, k = 1, compute_covariance = TRUE){
  K <- nrow(x$thetas)
  n <- nrow(x$data$locs.ord)
  if(is.null(x$data$rho_statistic)) x$data$rho_statistic <- matrix(0, K, n)
  for(j in k){
    cat(paste("Computing rho for Cluster ",j,"...\n",sep=""))
    U <- get_map(thetas = x$thetas[j,], datum = x$data$datum.ord[x$Z == j,], NNarray = x$data$NNarray, threshh = x$data$threshh)
    Prec <- U %*% t(U)
    rho <- numeric(n)
    pb <- txtProgressBar(min = 0, max = n, style = 3)
    if(!compute_covariance){
      for(i in 1:n){
        setTxtProgressBar(pb, i)
        rho[i] <- median(abs(cor_row_from_precision(Prec, i))[-i])
      }
    } else {
      Sigma <- solve(Prec)
      variances <- diag(Sigma)
      for(i in 1:n){
        setTxtProgressBar(pb, i)
        rho[i] <- median(abs(Sigma[i,]/sqrt(variances*variances[i]))[-i])
      }
      cat("\n")
    }
    x$data$rho_statistic[j,] <- rho
  }
  return(x)
}

